[slide]
# Training Session

[vimeo-video startTimeInSeconds="901"]
[stream language="EN" videoId="385258371"  /]
[stream language="RO" videoId="385463748" default /]
[/video-vimeo]

[/slide]