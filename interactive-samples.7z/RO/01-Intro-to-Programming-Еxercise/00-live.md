[slide]
# Live Session

[live-stream]
[stream language="EN" videoId="385258371"  /]
[stream language="RO" videoId="385463748" default /]
[/live-stream]

[slido id="5faavvrx" /]

[/slide]