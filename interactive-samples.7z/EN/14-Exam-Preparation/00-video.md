[slide]
# Training Session

[vimeo-video videoId="345620593" /]

[/slide]