[slide]
# Live Session

[live-stream videoId="345620593" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]