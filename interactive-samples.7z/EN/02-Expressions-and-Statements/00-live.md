[slide]
# Live Session

[live-stream videoId="341528681" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]