[slide]
# Summary

[vimeo-video videoId="341528681" startTimeInSeconds="9590" endTimeInSeconds="9642" /]

[/slide]