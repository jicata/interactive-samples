[slide]
# Summary

[vimeo-video videoId="342410322" startTimeInSeconds="9459" endTimeInSeconds="9477" /]

[/slide]