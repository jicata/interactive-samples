[slide]
# Training Session

[vimeo-video videoId="341539841" /]

[/slide]