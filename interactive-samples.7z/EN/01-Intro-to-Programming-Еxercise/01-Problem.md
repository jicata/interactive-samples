[slide]
# Problem: Print "Hello SoftUni"
[code-task title="Print Hello SoftUni" taskId="24-00E-p-01" executionType="tests-execution" executionStrategy="python-code"]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description

Write a program, which:

Prints "Hello SoftUni" on the console
[/task-description]
[code-io /]
[tests]
[test]
[input]
[/input]
[output]
Hello SoftUni
[/output]
[/test]
[/tests]
[/code-task]
[/slide]