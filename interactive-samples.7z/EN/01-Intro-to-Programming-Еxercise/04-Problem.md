[slide]
# Problem: Calculations
[code-task title="Calculations" taskId="24-00E-p-04" executionType="tests-execution" executionStrategy="python-code"]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description

Write a program, which calculates and prints the value of the following expressions:

* 5 + 3 \* 2
* 4 \* 3 \* 2
* 12 \/ 3 \* 2

# Output 

Print the result of each expression on a separate line
[/task-description]
[code-io /]
[tests]
[test]
[input]
[/input]
[output]
11
24
8.0
[/output]
[/test]
[/tests]
[/code-task]
[/slide]