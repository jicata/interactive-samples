[slide]
# Problem: Rectangle Area
[code-task title="Rectangle Area" taskId="24-00E-p-02" executionType="tests-execution" executionStrategy="python-code"]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description

Write a program, which:

* Calculates the area of the rectangle
* Sides of the rectangle are 5 and 10
[/task-description]
[code-io /]
[tests]
[test]
[input]
[/input]
[output]
50
[/output]
[/test]
[/tests]
[/code-task]
[/slide]