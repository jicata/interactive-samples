[slide]
# Problem: Triangle of Stars
[code-task title="Triangle of Stars" taskId="24-00E-p-05" executionType="tests-execution" executionStrategy="python-code"]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description
Write a program, which prints a triangle of stars. 

You should print one asteriks symbol \(\*\) for the first row, two asteriks symbols for the second row and so on for five rows. 

# Output
```
*
**
***
****
*****
```
[/task-description]
[code-io /]
[tests]
[test]
[input]
[/input]
[output]
\*
\*\*
\*\*\*
\*\*\*\*
\*\*\*\*\*
[/output]
[/test]
[/tests]
[/code-task]
[/slide]