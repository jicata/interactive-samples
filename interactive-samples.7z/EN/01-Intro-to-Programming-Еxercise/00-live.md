[slide]
# Live Session

[live-stream]
[stream language="EN" videoId="385258371" default /]
[stream language="RO" videoId="385463748"  /]
[/live-stream]

[slido id="5faavvrx" /]

[/slide]