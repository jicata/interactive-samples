[slide]
# Problem: Nums 1...10
[code-task title="Nums from 1 to 10" taskId="24-00E-p-03" executionType="tests-execution" executionStrategy="python-code"]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description

Write a program to print numbers from 1 to 10 (inclsuive).

# Output

Each number should be on a new line.
[/task-description]
[code-io /]
[tests]
[test]
[input]
[/input]
[output]
1
2
3
4
5
6
7
8
9
10
[/output]
[/test]
[/tests]
[/code-task]
[/slide]