[slide]
# Live Session

[live-stream videoId="341522009" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]