[slide]
# Live Session

[live-stream videoId="341582556" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]