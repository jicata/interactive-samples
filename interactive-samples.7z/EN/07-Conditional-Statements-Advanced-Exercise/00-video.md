[slide]
# Training Session

[vimeo-video videoId="341582556" /]

[/slide]