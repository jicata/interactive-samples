[slide]
# Problem: Numbers Ending in 7
[code-task title="Numbers Ending in 7" taskId="24-04E-p-04" executionType="tests-execution" executionStrategy="python-code" requiresInput]
[code-editor language=python]
```
# Write your code here
```
[/code-editor]
[task-description]
# Description

Write a program that **prints the numbers in the range** \[1...1000\], which **end in 7**. 

Print the numbers on a **single** line, separated by a **single space**.

# Example

| **Input** | | **Output** |
| --- | --- | --- |
| (no input) | | 7 17 27 ... 997 |
[/task-description]
[tests]
[test]
[output]
7 17 27 37 47 57 67 77 87 97 107 117 127 137 147 157 167 177 187 197 207 217 227 237 247 257 267 277 287 297 307 317 327 337 347 357 367 377 387 397 407 417 427 437 447 457 467 477 487 497 507 517 527 537 547 557 567 577 587 597 607 617 627 637 647 657 667 677 687 697 707 717 727 737 747 757 767 777 787 797 807 817 827 837 847 857 867 877 887 897 907 917 927 937 947 957 967 977 987 997
[/output]
[/test]
[/tests]
[code-io /]
[/code-task]
[/slide]