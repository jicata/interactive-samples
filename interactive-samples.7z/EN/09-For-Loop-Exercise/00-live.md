[slide]
# Live Session

[live-stream videoId="342471604" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]