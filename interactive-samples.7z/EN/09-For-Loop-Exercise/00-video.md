[slide]
# Training Session

[vimeo-video videoId="342471604" /]

[/slide]