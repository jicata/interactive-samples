[slide]
# Live Session

[live-stream]
[stream language="EN" videoId="351878876" default /]
[stream language="RO" videoId="384850106"  /]
[/live-stream]

[slido id="5faavvrx" /]

[/slide]