# Welcome to SoftUni

[slide]
# Video

[vimeo-video startTimeInSeconds="901" endTimeInSeconds="1379"]
[stream language="EN" videoId="351878876" default /]
[stream language="RO" videoId="384850106"  /]
[/video-vimeo]

[/slide]