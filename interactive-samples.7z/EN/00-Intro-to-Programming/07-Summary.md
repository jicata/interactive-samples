[slide]
# Summary

[vimeo-video startTimeInSeconds="8248" endTimeInSeconds="8300"]
[stream language="EN" videoId="351878876" default /]
[stream language="RO" videoId="384850106"  /]
[/video-vimeo]

[/slide]