[slide]
# Lesson Introduction

[vimeo-video startTimeInSeconds="1680" endTimeInSeconds="1756"]
[stream language="EN" videoId="351878876" default /]
[stream language="RO" videoId="384850106"  /]
[/video-vimeo]

[/slide]