[slide]
# Live Session

[live-stream videoId="343587107" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]