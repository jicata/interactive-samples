[slide]
# Summary

[vimeo-video videoId="343587107" startTimeInSeconds="9705" endTimeInSeconds="9822" /]

[/slide]