[slide]
# Live Session

[live-stream videoId="345011935" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]