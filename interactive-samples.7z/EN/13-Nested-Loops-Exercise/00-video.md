[slide]
# Training Session

[vimeo-video videoId="345011935" /]

[/slide]