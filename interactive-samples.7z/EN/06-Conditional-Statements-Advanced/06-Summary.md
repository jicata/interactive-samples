[slide]
# Summary

[vimeo-video videoId="341568008" startTimeInSeconds="8400" endTimeInSeconds="8437" /]

[/slide]