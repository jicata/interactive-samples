[slide]
# Live Session

[live-stream videoId="341568008" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]