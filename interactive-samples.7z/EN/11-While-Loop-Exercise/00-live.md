[slide]
# Live Session

[live-stream videoId="343678060" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]