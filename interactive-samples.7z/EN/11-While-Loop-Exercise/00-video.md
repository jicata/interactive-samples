[slide]
# Training Session

[vimeo-video videoId="343678060" /]

[/slide]