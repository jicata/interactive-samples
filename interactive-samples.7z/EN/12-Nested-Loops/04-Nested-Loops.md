[slide]
# Nested Loops
Statements that consist of several **loops** located **inside each other**

**Nested loops** are used:

* To execute an **action**, which **executes** multiple **actions**

* To make more **complex** calculations and variations
[/slide]

[slide]
# Video

[vimeo-video videoId="345185854" startTimeInSeconds="2796" endTimeInSeconds="3023" /]

[/slide]