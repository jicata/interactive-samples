[slide]
# Summary

[vimeo-video videoId="345185854" startTimeInSeconds="11287" endTimeInSeconds="11339" /]

[/slide]