[slide]
# Live Session

[live-stream videoId="345185854" playerType="vimeo" /]

[slido id="5faavvrx" /]

[/slide]